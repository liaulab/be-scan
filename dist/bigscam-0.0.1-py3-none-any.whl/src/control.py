import numpy as np

def print(word):
    print(word)

def np_zeros(num): 
    return np.zeros(num)
